
import React, { useState } from 'react';
import { Contact, Agent } from '../../../types';
import Card from '../../ui/Card';
import Modal from '../../ui/Modal';
import { PhoneIcon } from '../../ui/icons/PhoneIcon';
import { EmailIcon } from '../../ui/icons/EmailIcon';
import { UsersIcon } from '../../ui/icons/UsersIcon';
import { BuildingStorefrontIcon } from '../../ui/icons/BuildingStorefrontIcon';

interface ClientImportantContactsProps {
  contacts: Contact[];
  agent?: Agent;
}

const ClientImportantContacts: React.FC<ClientImportantContactsProps> = ({ contacts, agent }) => {
  const [isVendorModalOpen, setIsVendorModalOpen] = useState(false);

  return (
    <>
      <Card title="Your Team" icon={<UsersIcon />}>
        <p className="mb-4 text-sm">Here are the key people helping you on your journey. Don't hesitate to reach out!</p>
        <div className="space-y-4">
          {agent && (
            <div className="p-4 bg-indigo-50 rounded-lg border-l-4 border-indigo-500">
              <div className="flex items-center gap-4">
                  <img src={agent.photoUrl} alt={agent.name} className="h-16 w-16 rounded-full object-cover"/>
                  <div>
                      <p className="font-bold text-slate-800 text-lg">{agent.name}</p>
                      <p className="text-sm text-indigo-700 font-semibold">Your Agent</p>
                  </div>
              </div>
               <div className="mt-3 flex flex-col space-y-2">
                <a href={`tel:${agent.phone}`} className="inline-flex items-center text-sm text-slate-700 hover:text-indigo-600">
                  <PhoneIcon /> <span className="ml-2">{agent.phone}</span>
                </a>
                <a href={`mailto:${agent.email}`} className="inline-flex items-center text-sm text-slate-700 hover:text-indigo-600">
                  <EmailIcon /> <span className="ml-2">{agent.email}</span>
                </a>
              </div>
            </div>
          )}
          {contacts.map(contact => (
            <div key={contact.id} className="p-3 bg-slate-50 rounded-lg">
              <p className="font-semibold text-slate-800">{contact.name}</p>
              <p className="text-sm text-indigo-600 font-medium">{contact.role}{contact.company && `, ${contact.company}`}</p>
              <div className="mt-2 flex space-x-4">
                <a href={`tel:${contact.phone}`} className="inline-flex items-center text-sm text-slate-600 hover:text-indigo-600">
                  <PhoneIcon /> <span className="ml-1.5">{contact.phone}</span>
                </a>
                <a href={`mailto:${contact.email}`} className="inline-flex items-center text-sm text-slate-600 hover:text-indigo-600">
                  <EmailIcon /> <span className="ml-1.5">{contact.email}</span>
                </a>
              </div>
            </div>
          ))}
        </div>
        <button
            onClick={() => setIsVendorModalOpen(true)}
            className="mt-6 w-full inline-flex items-center justify-center px-4 py-2 bg-indigo-100 text-indigo-700 font-semibold rounded-md hover:bg-indigo-200 transition-colors"
        >
            <BuildingStorefrontIcon />
            <span className="ml-2">View Trusted Vendors</span>
        </button>
      </Card>
      <Modal isOpen={isVendorModalOpen} onClose={() => setIsVendorModalOpen(false)} title="Trusted Vendors">
        <div className="p-4 text-slate-600">
            <p>Here is a list of our trusted partners, from movers to painters. We've had great experiences with all of them!</p>
            <ul className="list-disc list-inside mt-4 space-y-2">
                <li><strong>ProMove Movers:</strong> (555) 111-2222 - Professional and efficient moving services.</li>
                <li><strong>ColorPerfect Painters:</strong> (555) 333-4444 - High-quality interior and exterior painting.</li>
                <li><strong>CleanSweep Home Cleaning:</strong> (555) 555-6666 - Deep cleaning services for move-in/move-out.</li>
                <li><strong>LockSolid Locksmiths:</strong> (555) 777-8888 - Rekeying and security system installation.</li>
            </ul>
        </div>
      </Modal>
    </>
  );
};

export default ClientImportantContacts;