
import React from 'react';
import { SearchCriteria } from '../../../types';
import { LinkIcon } from '../../ui/icons/LinkIcon';
import { ClipboardListIcon } from '../../ui/icons/ClipboardListIcon';

const ClientSearchCriteriaCard: React.FC<{ criteria: SearchCriteria }> = ({ criteria }) => {
  const ListItem: React.FC<{ title: string; items: string[] }> = ({ title, items }) => (
    <div>
      <h4 className="font-semibold text-slate-700">{title}</h4>
      <ul className="mt-1 space-y-1 text-slate-600 list-disc list-inside">
        {items.map((item, i) => <li key={i}>{item}</li>)}
      </ul>
    </div>
  );

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden">
      <div className="p-4 sm:p-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center">
             <div className="hidden sm:block text-indigo-500 mr-4"><ClipboardListIcon /></div>
             <h3 className="text-lg font-semibold text-slate-800 tracking-wide">Your Home Search Criteria</h3>
          </div>
          <a href={criteria.mlsSearchUrl} target="_blank" rel="noopener noreferrer" className="flex-shrink-0 w-full sm:w-auto inline-flex items-center justify-center px-4 py-2 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 transition-colors">
              <LinkIcon /> <span className="ml-2">View Listings</span>
          </a>
        </div>
        <div className="mt-4 pt-4 border-t grid grid-cols-1 md:grid-cols-3 gap-x-6 gap-y-4">
          <ListItem title="Must-Haves" items={criteria.nonNegotiables} />
          <ListItem title="Nice-to-Haves" items={criteria.niceToHaves} />
           <div>
              <h4 className="font-semibold text-slate-700">Neighborhoods / Zip Codes</h4>
              <p className="mt-1 text-slate-600 whitespace-pre-wrap">{criteria.neighborhoodsOrZipCodes}</p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default ClientSearchCriteriaCard;