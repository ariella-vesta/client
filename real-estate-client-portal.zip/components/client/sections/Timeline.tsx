
import React, { useState } from 'react';
import { TimelineEvent } from '../../../types';
import Modal from '../../ui/Modal';
import { VideoIcon } from '../../ui/icons/VideoIcon';
import { CheckCircleIcon } from '../../ui/icons/CheckCircleIcon';
import { ClockIcon } from '../../ui/icons/ClockIcon';
import { ExclamationCircleIcon } from '../../ui/icons/ExclamationCircleIcon';

interface ClientTimelineProps {
  events: TimelineEvent[];
}

const statusStyles = {
  complete: {
    icon: <CheckCircleIcon className="text-green-500" />,
    bgColor: 'bg-green-100',
    borderColor: 'border-green-500',
    textColor: 'text-green-700',
  },
  current: {
    icon: <ExclamationCircleIcon className="text-blue-500" />,
    bgColor: 'bg-blue-100',
    borderColor: 'border-blue-500',
    textColor: 'text-blue-700',
  },
  upcoming: {
    icon: <ClockIcon className="text-slate-500" />,
    bgColor: 'bg-slate-100',
    borderColor: 'border-slate-400',
    textColor: 'text-slate-700',
  },
};

const ClientTimeline: React.FC<ClientTimelineProps> = ({ events }) => {
  const [modalVideoUrl, setModalVideoUrl] = useState<string | null>(null);
  const sortedEvents = [...events].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <div className="bg-white p-6 sm:p-8 rounded-xl shadow-md">
      <h3 className="text-xl font-semibold text-slate-800 tracking-wide mb-6">Your Home Buying Timeline</h3>
      <div className="relative border-l-2 border-slate-200 ml-3">
        {sortedEvents.map((event, index) => {
          const styles = statusStyles[event.status];
          return (
            <div key={event.id} className="mb-8 ml-8 relative">
              <div className={`absolute -left-11 -top-1 flex items-center justify-center w-8 h-8 rounded-full ${styles.bgColor}`}>
                {styles.icon}
              </div>
              <div className={`p-4 rounded-lg bg-slate-50 border-l-4 ${styles.borderColor}`}>
                <time className={`mb-1 text-sm font-normal leading-none ${styles.textColor}`}>{new Date(event.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</time>
                <h4 className="text-lg font-semibold text-slate-900">{event.title}</h4>
                <p className="mb-2 text-base font-normal text-slate-600">{event.description}</p>
                {event.videoUrl && (
                  <button
                    onClick={() => setModalVideoUrl(event.videoUrl!)}
                    className="inline-flex items-center px-4 py-2 text-sm font-medium text-indigo-700 bg-indigo-100 border border-transparent rounded-md hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                  >
                    <VideoIcon />
                    <span className="ml-2">Watch Explainer</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
      <Modal isOpen={!!modalVideoUrl} onClose={() => setModalVideoUrl(null)} title="Explainer Video">
        {modalVideoUrl && (
          <div className="aspect-w-16 aspect-h-9">
            <iframe
              src={modalVideoUrl}
              title="YouTube video player"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full"
              style={{height: '50vh'}}
            ></iframe>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default ClientTimeline;