
import React from 'react';
import { ExploratoryAppointment } from '../../../types';
import Card from '../../ui/Card';
import { CalendarIcon } from '../../ui/icons/CalendarIcon';
import { GoogleCalendarIcon } from '../../ui/icons/GoogleCalendarIcon';

interface ClientExploratoryAppointmentProps {
  appointment: ExploratoryAppointment;
}

const ClientExploratoryAppointmentCard: React.FC<ClientExploratoryAppointmentProps> = ({ appointment }) => {
  return (
    <Card title="Step 3: Exploratory Appointment" icon={<CalendarIcon />}>
      <div className="space-y-3">
        <div>
          <p className="text-sm font-medium text-slate-500">Date & Time</p>
          <p className="font-semibold text-slate-800">{new Date(appointment.date).toLocaleString('en-US', { dateStyle: 'full', timeStyle: 'short' })}</p>
        </div>
        <div className="flex flex-col space-y-2 pt-2">
            {appointment.googleCalendarLink && (
                 <a href={appointment.googleCalendarLink} target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-indigo-600 hover:text-indigo-800 font-medium">
                    <GoogleCalendarIcon /> <span className="ml-2">Add to Google Calendar</span>
                </a>
            )}
        </div>
      </div>
    </Card>
  );
};

export default ClientExploratoryAppointmentCard;