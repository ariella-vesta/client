
import React, { useState } from 'react';
import { BuyerDocument, UploadedFile } from '../../../types';
import Card from '../../ui/Card';
import Modal from '../../ui/Modal';
import { DocumentTextIcon } from '../../ui/icons/DocumentTextIcon';
import { LinkIcon } from '../../ui/icons/LinkIcon';
import { EyeIcon } from '../../ui/icons/EyeIcon';

interface ClientDocumentListProps {
    documents: BuyerDocument[];
    title: string;
}

const ClientDocumentList: React.FC<ClientDocumentListProps> = ({ documents, title }) => {
  const [previewFile, setPreviewFile] = useState<UploadedFile | null>(null);

  return (
    <>
      <Card title={title} icon={<DocumentTextIcon/>}>
        <p className="mb-4 text-sm">Here are your important contract documents for your records. Click to preview or download.</p>
        <ul className="divide-y divide-slate-200">
          {documents.map(doc => (
            <li key={doc.id} className="py-3 flex items-center justify-between">
              <p className="font-medium text-slate-900">{doc.title}</p>
              {doc.file ? (
                   <div className="flex items-center space-x-2">
                        <button 
                            onClick={() => setPreviewFile(doc.file!)}
                            className="inline-flex items-center px-3 py-1.5 bg-white text-slate-700 text-sm font-semibold rounded-md hover:bg-slate-100 border border-slate-300 transition-colors"
                        >
                            <EyeIcon />
                            <span className="ml-2">Preview</span>
                        </button>
                        <a 
                            href={doc.file.url} 
                            download={doc.file.name}
                            className="inline-flex items-center px-3 py-1.5 bg-indigo-100 text-indigo-700 text-sm font-semibold rounded-md hover:bg-indigo-200 transition-colors"
                        >
                            <LinkIcon />
                            <span className="ml-2">Download</span>
                        </a>
                   </div>
              ) : (
                  <span className="text-sm text-slate-400">Not available</span>
              )}
            </li>
          ))}
        </ul>
      </Card>

      <Modal isOpen={!!previewFile} onClose={() => setPreviewFile(null)} title={previewFile?.name || 'Document Preview'}>
        {previewFile && (
          <div style={{ width: '100%', height: '75vh' }}>
            <iframe
              src={previewFile.url}
              title={previewFile.name}
              width="100%"
              height="100%"
              style={{ border: 'none' }}
            >
              Your browser does not support PDFs. Please download the file to view it.
            </iframe>
          </div>
        )}
      </Modal>
    </>
  );
};

export default ClientDocumentList;