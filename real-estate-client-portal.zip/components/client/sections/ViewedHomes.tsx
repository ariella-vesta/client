
import React from 'react';
import { ViewedHome } from '../../../types';
import Card from '../../ui/Card';
import { HomeIcon } from '../../ui/icons/HomeIcon';
import { LinkIcon } from '../../ui/icons/LinkIcon';


const ClientViewedHomes: React.FC<{ homes: ViewedHome[]; onUpdate: (updatedHome: ViewedHome) => void; }> = ({ homes, onUpdate }) => {
  
  const handleRatingChange = (id: number, rating: number) => {
    const homeToUpdate = homes.find(h => h.id === id);
    if (homeToUpdate) {
        onUpdate({ ...homeToUpdate, ranking: rating });
    }
  };

  const handleNotesChange = (id: number, notes: string) => {
    const homeToUpdate = homes.find(h => h.id === id);
    if (homeToUpdate) {
        onUpdate({ ...homeToUpdate, notes: notes });
    }
  };
  
  const formatCurrency = (amount: number | undefined) => {
    if (typeof amount !== 'number') return '';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <Card title="Viewed Homes" className="lg:col-span-2" icon={<HomeIcon/>}>
        <p className="mb-4 text-sm">Keep track of the homes you've seen. Add your ratings and notes to help us find your perfect match!</p>
      <div className="space-y-6">
        {homes.map(home => (
          <div key={home.id} className="flex flex-col sm:flex-row gap-4 p-4 border bg-slate-50 rounded-lg">
            <img src={home.imageUrl} alt={`View of ${home.address}`} className="w-full sm:w-48 h-40 object-cover rounded-md flex-shrink-0" />
            <div className="flex-1 space-y-2">
                <h4 className="font-bold text-lg text-slate-800">{home.address}</h4>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-slate-500">
                    <span className="flex items-center font-medium">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1.5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                        Viewed: {new Date(home.viewedDate).toLocaleDateString()}
                    </span>
                    {home.price && <span className="font-semibold text-indigo-600">{formatCurrency(home.price)}</span>}
                    {home.neighborhood && <span>{home.neighborhood}</span>}
                    {home.mlsLink && (
                        <a href={home.mlsLink} target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-indigo-600 hover:underline">
                            View Listing <LinkIcon />
                        </a>
                    )}
                </div>
                
                <div className="pt-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor={`rating-${home.id}`} className="text-sm font-medium text-slate-700">Your Rating (1-10)</label>
                        <select
                            id={`rating-${home.id}`}
                            value={home.ranking}
                            onChange={(e) => handleRatingChange(home.id, parseInt(e.target.value, 10))}
                            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                        >
                            {Array.from({ length: 10 }, (_, i) => i + 1).map(num => (
                                <option key={num} value={num}>{num}</option>
                            ))}
                        </select>
                    </div>
                     <div>
                        <label htmlFor={`notes-${home.id}`} className="text-sm font-medium text-slate-700">Your Notes</label>
                        <textarea
                            id={`notes-${home.id}`}
                            className="mt-1 w-full p-2 border border-slate-300 rounded-md text-sm focus:ring-indigo-500 focus:border-indigo-500"
                            rows={3}
                            value={home.notes}
                            onChange={(e) => handleNotesChange(home.id, e.target.value)}
                            placeholder="e.g., 'Loved the kitchen...'"
                        />
                    </div>
                </div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
};

export default ClientViewedHomes;