
import React from 'react';
import { StrategySession } from '../../../types';
import Card from '../../ui/Card';
import { CalendarIcon } from '../../ui/icons/CalendarIcon';
import { VideoIcon } from '../../ui/icons/VideoIcon';
import { LinkIcon } from '../../ui/icons/LinkIcon';
import { GoogleCalendarIcon } from '../../ui/icons/GoogleCalendarIcon';

interface ClientStrategySessionProps {
  session: StrategySession;
}

const ClientStrategySessionCard: React.FC<ClientStrategySessionProps> = ({ session }) => {
  return (
    <Card title="Step 2: Strategy Session" icon={<CalendarIcon />}>
      <div className="space-y-3">
        <div>
          <p className="text-sm font-medium text-slate-500">Date & Time</p>
          <p className="font-semibold text-slate-800">{new Date(session.date).toLocaleString('en-US', { dateStyle: 'full', timeStyle: 'short' })}</p>
        </div>
        <div className="flex flex-col space-y-2 pt-2">
            <a href={session.zoomLink} target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-indigo-600 hover:text-indigo-800 font-medium">
                <LinkIcon /> <span className="ml-2">Join Session (Zoom)</span>
            </a>
            {session.googleCalendarLink && (
                 <a href={session.googleCalendarLink} target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-indigo-600 hover:text-indigo-800 font-medium">
                    <GoogleCalendarIcon /> <span className="ml-2">Add to Google Calendar</span>
                </a>
            )}
            <a href={session.recordingUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-indigo-600 hover:text-indigo-800 font-medium">
                <VideoIcon /> <span className="ml-2">View Recording</span>
            </a>
        </div>
      </div>
    </Card>
  );
};

export default ClientStrategySessionCard;